package com.waa.assignment1.service;

import com.waa.assignment1.entity.Post;
import com.waa.assignment1.entity.dto.request.PostDto;

import java.util.List;

public interface PostService {
    List<Post> getAllPosts(String author);

    void createPost(PostDto post);

    Post getPostById(long id);

    void updatePost(long id, PostDto post);

    void deletePost(long id);
}
