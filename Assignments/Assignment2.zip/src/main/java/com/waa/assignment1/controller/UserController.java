package com.waa.assignment1.controller;

import com.waa.assignment1.entity.Post;
import com.waa.assignment1.entity.User;
import com.waa.assignment1.entity.dto.request.UserDto;
import com.waa.assignment1.service.UserService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    private UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public List<User> getUsers(@RequestParam(value = "hasPosts", required = false) boolean hasPosts) {
        return userService.getUsers(hasPosts);
    }

    @GetMapping("/{id}")
    public User getUser(@PathVariable long id) {
        return userService.getUser(id);
    }

    @PostMapping
    public void createUser(@RequestBody UserDto user) {
        userService.createUser(user);
    }

    @GetMapping("/{id}/posts")
    public List<Post> getPosts(@PathVariable long id) {
        return userService.getPosts(id);
    }

}
