package com.waa.assignment1.service;

import com.waa.assignment1.entity.Post;
import com.waa.assignment1.entity.User;
import com.waa.assignment1.entity.dto.request.UserDto;

import java.util.List;

public interface UserService {
    List<User> getUsers(boolean hasPosts);

    User getUser(long id);

    void createUser(UserDto user);

    List<Post> getPosts(long id);
}
