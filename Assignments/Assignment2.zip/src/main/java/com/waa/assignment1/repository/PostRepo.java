package com.waa.assignment1.repository;

import com.waa.assignment1.entity.Post;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PostRepo extends JpaRepository<Post, Long> {
}
