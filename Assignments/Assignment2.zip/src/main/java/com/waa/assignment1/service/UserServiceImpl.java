package com.waa.assignment1.service;

import com.waa.assignment1.entity.Post;
import com.waa.assignment1.entity.User;
import com.waa.assignment1.entity.dto.request.UserDto;
import com.waa.assignment1.repository.UserRepo;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private UserRepo userRepo;
    private ModelMapper modelMapper;

    public UserServiceImpl(UserRepo userRepo, ModelMapper modelMapper) {
        this.userRepo = userRepo;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<User> getUsers(boolean hasPosts) {
        List<User> users = userRepo.findAll();
        if (hasPosts) {
            users.removeIf(user -> user.getPosts().size() <= 1);
        }
        return users;
    }

    @Override
    public User getUser(long id) {
        return userRepo.findById(id).get();
    }

    @Override
    public void createUser(UserDto user) {
        User u = new User();
        u.setName(user.getName());
        userRepo.save(u);
    }

    @Override
    public List<Post> getPosts(long id) {
        return userRepo.findById(id).get().getPosts();
    }
}
