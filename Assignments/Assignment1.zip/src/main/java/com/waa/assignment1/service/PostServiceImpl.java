package com.waa.assignment1.service;

import com.waa.assignment1.entity.Post;
import com.waa.assignment1.entity.dto.request.PostDto;
import com.waa.assignment1.repository.PostRepo;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PostServiceImpl implements PostService {

    private PostRepo postRepo;
    private ModelMapper modelMapper;

    public PostServiceImpl(PostRepo postRepo, ModelMapper modelMapper) {
        this.postRepo = postRepo;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<Post> getAllPosts(String author) {
        List<Post> p = postRepo.getAllPosts();

        if (author != null) {
            p.removeIf(post -> !post.getAuthor().contains(author));
        }
        return p;
    }

    @Override
    public void createPost(PostDto post) {
        Post p = modelMapper.map(post, Post.class);
        postRepo.createPost(p);
    }

    @Override
    public Post getPostById(long id) {
        return postRepo.getPostById(id);
    }

    @Override
    public void updatePost(long id, PostDto post) {
        Post p = postRepo.getPostById(id);
        p.setAuthor(post.getAuthor());
        p.setContent(post.getContent());
        p.setTitle(post.getTitle());
        postRepo.updatePost(p);
    }

    @Override
    public void deletePost(long id) {
        postRepo.deletePost(id);
    }


}
