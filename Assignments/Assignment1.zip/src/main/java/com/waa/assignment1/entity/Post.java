package com.waa.assignment1.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Post {
    long id;
    String title;
    String content;
    String author;

    public Post(long id, String title, String content, String author) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.author = author;
    }

    public Post() {}
}
