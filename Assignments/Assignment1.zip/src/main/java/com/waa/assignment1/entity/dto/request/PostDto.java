package com.waa.assignment1.entity.dto.request;

import lombok.Data;

@Data
public class PostDto {
    private String title;
    private String content;
    private String author;
}
