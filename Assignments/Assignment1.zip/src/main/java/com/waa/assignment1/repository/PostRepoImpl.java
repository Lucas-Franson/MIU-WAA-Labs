package com.waa.assignment1.repository;

import com.waa.assignment1.entity.Post;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class PostRepoImpl implements PostRepo {

    private static ArrayList<Post> posts = new ArrayList<>() {
        {
            add(new Post(1, "Post 1", "Content 1", "Author 1"));
            add(new Post(2, "Post 2", "Content 2", "Author 2"));
            add(new Post(3, "Post 3", "Content 3", "Author 3"));
        }
    };


    @Override
    public List<Post> getAllPosts() {
        return posts;
    }

    @Override
    public Post createPost(Post post) {
        long id = posts.stream().max((p1, p2) -> Long.compare(p1.getId(), p2.getId())).get().getId();
        post.setId(id + 1);
        posts.add(post);
        return post;
    }

    @Override
    public Post getPostById(long id) {
        return posts.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }

    @Override
    public void updatePost(Post p) {
        Post post = posts.stream().filter(post1 -> post1.getId() == p.getId()).findFirst().orElse(null);
        if (post != null) {
            post.setAuthor(p.getAuthor());
            post.setContent(p.getContent());
            post.setTitle(p.getTitle());
        }
    }

    @Override
    public void deletePost(long id) {
        posts.removeIf(post -> post.getId() == id);
    }
}
