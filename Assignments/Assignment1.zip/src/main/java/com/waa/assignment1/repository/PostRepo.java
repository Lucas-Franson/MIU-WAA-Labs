package com.waa.assignment1.repository;

import com.waa.assignment1.entity.Post;

import java.util.List;

public interface PostRepo {
    List<Post> getAllPosts();

    Post createPost(Post post);

    Post getPostById(long id);

    void updatePost(Post p);

    void deletePost(long id);
}
