package com.waa.assignment1.aspect;

import com.waa.assignment1.entity.ExceptionEntity;
import com.waa.assignment1.repository.ExceptionRepo;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalTime;

@Aspect
@Component
public class ExceptionAspect {

    private ExceptionRepo exceptionRepo;

    public ExceptionAspect(ExceptionRepo exceptionRepo) {
        this.exceptionRepo = exceptionRepo;
    }

    @AfterThrowing(pointcut = "execution(* com.waa.assignment1.controller.*.*(..))", throwing = "ex")
    public void afterThrowing(Exception ex) {

        ExceptionEntity exceptionEntity = new ExceptionEntity();

        exceptionEntity.setPrinciple("principle");
        exceptionEntity.setOperation(ex.getStackTrace().toString());
        exceptionEntity.setDate(LocalDate.now());
        exceptionEntity.setTime(LocalTime.now());
        exceptionEntity.setExceptionType(ex.getClass().getName());

        exceptionRepo.save(exceptionEntity);
    }

}
