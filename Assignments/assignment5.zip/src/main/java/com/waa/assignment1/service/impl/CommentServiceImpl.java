package com.waa.assignment1.service.impl;

import com.waa.assignment1.repository.CommentRepo;
import com.waa.assignment1.service.CommentService;
import org.springframework.stereotype.Service;

@Service
public class CommentServiceImpl implements CommentService {

    private CommentRepo commentRepo;

    public CommentServiceImpl(CommentRepo commentRepo) {
        this.commentRepo = commentRepo;
    }

}
