package com.waa.assignment1.service;

import com.waa.assignment1.entity.dto.request.LoginRequest;
import com.waa.assignment1.entity.dto.request.RefreshTokenRequest;
import com.waa.assignment1.entity.dto.response.LoginResponse;

public interface AuthService {
    LoginResponse login(LoginRequest loginRequest);
    LoginResponse refreshToken(RefreshTokenRequest refreshTokenRequest);
}
