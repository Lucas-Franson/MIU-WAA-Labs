package com.waa.assignment1.controller;

import com.waa.assignment1.aspect.annotation.ExecutionTime;
import com.waa.assignment1.entity.Comment;
import com.waa.assignment1.entity.Post;
import com.waa.assignment1.entity.User;
import com.waa.assignment1.entity.dto.request.UserDto;
import com.waa.assignment1.service.UserService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/users")
public class UserController {

    private UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public List<User> getUsers() {
        return userService.getUsers();
    }

    @ExecutionTime
    @GetMapping("/{id}")
    public User getUser(@PathVariable long id) {
        return userService.getUser(id);
    }

    @PostMapping
    public void createUser(@RequestBody UserDto user) {
        userService.createUser(user);
    }

    @GetMapping("/{id}/posts")
    public List<Post> getPosts(@PathVariable long id) {
        return userService.getPosts(id);
    }

    @GetMapping("/{id}/posts/{postId}")
    public Post getPost(@PathVariable long id, @PathVariable long postId) {
        return userService.getPostById(id, postId);
    }

    @GetMapping("/{id}/posts/{postId}/comments/{commentId}")
    public Comment getComment(@PathVariable long id, @PathVariable long postId, @PathVariable long commentId) {
        return userService.getComment(id, postId, commentId);
    }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable long id) {
        userService.deleteUser(id);
    }

    @GetMapping("/posts/title")
    public List<User> getAllUsersWithPosts(@RequestParam String title) {
        return userService.getAllUsersWithPostsTitle(title);
    }

    @GetMapping("/throw/error")
    public void throwError() {
        throw new RuntimeException("Error");
    }

}
