package com.waa.assignment1.service.impl;

import com.waa.assignment1.entity.Comment;
import com.waa.assignment1.entity.Post;
import com.waa.assignment1.entity.dto.request.PostDto;
import com.waa.assignment1.repository.PostRepo;
import com.waa.assignment1.service.PostService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PostServiceImpl implements PostService {

    private PostRepo postRepo;
    private ModelMapper modelMapper;

    public PostServiceImpl(PostRepo postRepo, ModelMapper modelMapper) {
        this.postRepo = postRepo;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<Post> getAllPosts(String author, String title) {
        if (author != null && title != null)
            return postRepo.findAllByAuthorAndTitle(author, title);
        if (author != null)
            return postRepo.findAllByAuthor(author);
        if (title != null)
            return postRepo.findAllByTitle(title);

        return postRepo.findAll();
    }

    @Override
    public void createPost(PostDto post) {
        Post p = modelMapper.map(post, Post.class);
        postRepo.save(p);
    }

    @Override
    public Post getPostById(long id) {
        return postRepo.findById(id).get();
    }

    @Override
    public void updatePost(long id, PostDto post) {
        Post p = postRepo.findById(id).get();
        p.setAuthor(post.getAuthor());
        p.setContent(post.getContent());
        p.setTitle(post.getTitle());
        postRepo.save(p);
    }

    @Override
    public void deletePost(long id) {
        postRepo.deleteById(id);
    }

    @Override
    public void addComment(long id, String comment) {
        Post p = postRepo.findById(id).get();
        Comment c = new Comment();
        c.setName(comment);
        p.getComments().add(c);
        postRepo.save(p);
    }

}
