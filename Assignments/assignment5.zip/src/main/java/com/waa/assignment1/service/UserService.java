package com.waa.assignment1.service;

import com.waa.assignment1.entity.Comment;
import com.waa.assignment1.entity.Post;
import com.waa.assignment1.entity.User;
import com.waa.assignment1.entity.dto.request.UserDto;

import java.util.List;

public interface UserService {
    List<User> getUsers();

    User getUser(long id);

    void createUser(UserDto user);

    List<Post> getPosts(long id);

    List<User> getAllUsersWithPosts();

    List<User> getAllUsersWithPostsTitle(String title);

    void deleteUser(long id);

    Post getPostById(long id, long postId);

    Comment getComment(long id, long postId, long commentId);
}
