package com.waa.assignment1.controller;

import com.waa.assignment1.entity.Post;
import com.waa.assignment1.entity.dto.request.PostDto;
import com.waa.assignment1.service.PostService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/posts")
public class PostController {

    private PostService postService;

    public PostController(PostService postService) {
        this.postService = postService;
    }

    @GetMapping
    public List<Post> getPosts(@RequestParam(value = "author", required = false) String author,
                               @RequestParam(value = "title", required = false) String title) {
        return postService.getAllPosts(author, title);
    }

    @PostMapping
    public void createPost(@RequestBody PostDto post) {
        postService.createPost(post);
    }

    @GetMapping("/{id}")
    public Post getPostById(@PathVariable long id) {
        return postService.getPostById(id);
    }

    @PutMapping("/{id}")
    public void updatePost(@PathVariable long id, @RequestBody PostDto post) {
        postService.updatePost(id, post);
    }

    @DeleteMapping("/{id}")
    public void deletePost(@PathVariable long id) {
        postService.deletePost(id);
    }

    @PostMapping("/{id}/comments")
    public void addComment(@PathVariable long id, @RequestBody String comment) {
        postService.addComment(id, comment);
    }

}
