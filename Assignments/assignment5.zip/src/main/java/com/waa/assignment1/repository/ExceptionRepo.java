package com.waa.assignment1.repository;

import com.waa.assignment1.entity.ExceptionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExceptionRepo extends JpaRepository<ExceptionEntity, Long> {
}
