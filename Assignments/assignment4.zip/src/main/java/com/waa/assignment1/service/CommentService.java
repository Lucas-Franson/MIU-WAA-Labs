package com.waa.assignment1.service;

public interface CommentService {
}
