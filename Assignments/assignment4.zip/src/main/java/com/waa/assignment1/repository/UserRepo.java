package com.waa.assignment1.repository;

import com.waa.assignment1.entity.Comment;
import com.waa.assignment1.entity.Post;
import com.waa.assignment1.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface UserRepo extends JpaRepository<User, Long> {
    @Query("select u from User u where size(u.posts) >= :size")
    List<User> findAllByPostsSizeGreaterThanEqual(@Param("size") int size);

    @Query("select u from User u join u.posts p where p.title like %:title%")
    List<User> findAllByPostsTitleContains(@Param("title") String title);

    @Query("select p from User u join u.posts p where u.id = :id and p.id = :postId")
    Post findPostById(@Param("id") long id, @Param("postId") long postId);

    @Query("select c from User u join u.posts p join p.comments c where u.id = :id and p.id = :postId and c.id = :commentId")
    Comment findCommentById(long id, long postId, long commentId);
}
