package com.waa.assignment1.entity.dto.request;

import lombok.Data;

@Data
public class UserDto {
    private String name;
}
