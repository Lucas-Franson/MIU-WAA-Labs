package com.waa.assignment1.service;

import com.waa.assignment1.entity.Comment;
import com.waa.assignment1.entity.Post;
import com.waa.assignment1.entity.User;
import com.waa.assignment1.entity.dto.request.UserDto;
import com.waa.assignment1.repository.UserRepo;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private UserRepo userRepo;
    private ModelMapper modelMapper;

    public UserServiceImpl(UserRepo userRepo, ModelMapper modelMapper) {
        this.userRepo = userRepo;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<User> getUsers() {
        return userRepo.findAll();
    }

    @Override
    public User getUser(long id) {
        return userRepo.findById(id).get();
    }

    @Override
    public void createUser(UserDto user) {
        User u = new User();
        u.setName(user.getName());
        userRepo.save(u);
    }

    @Override
    public List<Post> getPosts(long id) {
        return userRepo.findById(id).get().getPosts();
    }

    @Override
    public List<User> getAllUsersWithPosts() {
        return userRepo.findAllByPostsSizeGreaterThanEqual(1);
    }

    @Override
    public List<User> getAllUsersWithPostsTitle(String title) {
        return userRepo.findAllByPostsTitleContains(title);
    }

    @Override
    public void deleteUser(long id) {
        userRepo.deleteById(id);
    }

    @Override
    public Post getPostById(long id, long postId) {
        return userRepo.findPostById(id, postId);
    }

    @Override
    public Comment getComment(long id, long postId, long commentId) {
        return userRepo.findCommentById(id, postId, commentId);
    }
}
