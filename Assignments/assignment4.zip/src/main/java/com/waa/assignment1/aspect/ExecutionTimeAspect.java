package com.waa.assignment1.aspect;

import com.waa.assignment1.entity.Logger;
import com.waa.assignment1.repository.LoggerRepo;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Aspect
@Component
public class ExecutionTimeAspect {

    private LoggerRepo logger;

    public ExecutionTimeAspect(LoggerRepo logger) {
        this.logger = logger;
    }

    @Around("@annotation(com.waa.assignment1.aspect.annotation.ExecutionTime)")
    public Object serviceExecution(ProceedingJoinPoint joinPoint) throws Throwable {
        LocalDateTime start = LocalDateTime.now();

        Object o = joinPoint.proceed();

        LocalDateTime end = LocalDateTime.now();

        Logger l = new Logger();
        l.setDate(start.toLocalDate());
        l.setTime(start.toLocalTime());
        l.setPrinciple("principle");
        l.setOperation(joinPoint.getSignature().getName());
        logger.save(l);

        return o;
    }

}
