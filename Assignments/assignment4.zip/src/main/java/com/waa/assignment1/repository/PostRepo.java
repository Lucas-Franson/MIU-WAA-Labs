package com.waa.assignment1.repository;

import com.waa.assignment1.entity.Post;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PostRepo extends JpaRepository<Post, Long> {

    List<Post> findAllByAuthorAndTitle(String author, String title);
    List<Post> findAllByAuthor(String author);
    List<Post> findAllByTitle(String title);

}
