
INSERT INTO users (id, name)
VALUES (1, 'John Doe'),
         (2, 'Jane Doe');

INSERT INTO post (id, author_id, content, title)
VALUES (1, 1, 'Hello World', 'Introduction'),
         (2, 1, 'Introduction to Spring Boot', 'Spring Boot'),
         (3, 2, 'Spring Boot in Action', 'Spring Boot - Tips and Tricks');

INSERT INTO comment (id, post_id, name)
VALUES (1, 1, 'John Doe'),
         (2, 1, 'Jane Doe'),
         (3, 2, 'John Doe'),
         (4, 3, 'John Doe');